package Utils;

public class PersistenceUnitReader {
	public static String getPersistenceUnitName() {
		String unit = "hibernate";
		return unit;
	}
}
